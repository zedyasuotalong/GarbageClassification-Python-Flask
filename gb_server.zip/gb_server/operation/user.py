from models.user import Users

# lei
class User_opration():
    def __init__(self):
        self.__fields__ = ['id','username','password'] 

    def _all(self):
        print('operation')
        user_list =  Users.query.all()
        print(user_list)
        return user_list
    
    def _login(self,name,pwd):
        user_list =  Users.query.filter_by(username=name).first()
        return user_list