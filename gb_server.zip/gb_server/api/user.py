from operation.user import User_opration
from utils.data_process import Class_To_Data
def User_list():
    print('api')
    u_o = User_opration()
    data = u_o._all()
    # data（复杂对象）====> 数据
    data = Class_To_Data(data, u_o.__fields__, 0)
    print(data)
    return data


# def User_reg(kwargs):
#     u_o = User_operation()
#     data = u_o._reg(kwargs)
#     return data

def User_login(name,pwd):
    u_o = User_opration()
    data = u_o._login(name,pwd)
    # data = {
    #     code:0,
    #     message:""
    # }
    # print(data)
    data = Class_To_Data(data,u_o.__fields__, 1)
    print(data)
    # data 
    # 
    # 
    # if data['password'] === pwd
    #  else
    return data