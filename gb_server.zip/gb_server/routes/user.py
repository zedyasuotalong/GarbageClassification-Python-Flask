
from flask import Blueprint,request
import json
user = Blueprint('user',__name__)

from api.user import *

@user.route('/list',methods=['GET'])
def list():
    # api的业务逻辑方法
    print('route')
    data = User_list()
    return data

@user.route('/login',methods=['GET'])
def login():
    name = request.args['username']
    pwd = request.args['password']

    data = User_login(name,pwd)
    return "123"

# @user.route('/reg',methods=['POST'])
# def reg():
#     data = json.loads(request.data)

#     data = User_reg({
#         "sername":data['username']


        
#     }})
#     return "123"
