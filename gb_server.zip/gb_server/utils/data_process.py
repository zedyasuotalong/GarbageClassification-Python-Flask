
# 数据模型类===》普通字典
#    user/[user,user,user]    属性清单,

#                  数据源     数据模型类属性    0 obj / 1
def Class_To_Data(data_list,fields,type=0):
    if not type:  #[obj,obj]
        user_list = []  
        for u in data_list:
            temp = {}
            for f in fields:
                temp[f] = getattr(u,f)
            user_list.append(temp)
    # else:   #   obj
    #     user_list = {}
    #     for f in fields:
    #         if f in ['create_time', 'login_time']:
    #             d = getattr(data_list, f)
    #             if d:
    #                 user_list[f] = datetime.datetime.strftime(d, "%Y-%m-%d %H:%M:%S ")
    #         else:
    #             user_list[f] = getattr(data_list, f)

    return user_list