
#                                                            mysql=====>sql
# flask ---> pymysql库--> sqlalchemy（ORM）==》flask_sqlalchemy ====>面向对象方式操作数据
#                                            models     模型类
#                                            operation  调用模型类数据库
#                                            api        一系列方法：业务逻辑    数据封装
#                                            routes     路由配置   request  retu
#                                            app.py